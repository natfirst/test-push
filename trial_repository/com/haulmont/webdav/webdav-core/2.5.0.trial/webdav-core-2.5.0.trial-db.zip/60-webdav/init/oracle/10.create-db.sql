-- begin WEBDAV_WEBDAV_DOCUMENT_VERSION
create table WEBDAV_WEBDAV_DOCUMENT_VERSION (
    ID varchar2(32),
    VERSION number(10) not null,
    CREATE_TS timestamp,
    CREATED_BY varchar2(50 char),
    UPDATE_TS timestamp,
    UPDATED_BY varchar2(50 char),
    DELETE_TS timestamp,
    DELETED_BY varchar2(50 char),
    --
    FILE_DESCRIPTOR_ID varchar2(32),
    WEBDAV_DOCUMENT_ID varchar2(32),
    CONTENT_TYPE varchar2(255 char) not null,
    SHA1SUM varchar2(255 char) not null,
    NATURAL_VERSION_ID number(19),
    --
    primary key (ID)
)^
-- end WEBDAV_WEBDAV_DOCUMENT_VERSION
-- begin WEBDAV_WEBDAV_DOCUMENT
create table WEBDAV_WEBDAV_DOCUMENT (
    ID varchar2(32),
    VERSION number(10) not null,
    CREATE_TS timestamp,
    CREATED_BY varchar2(50 char),
    UPDATE_TS timestamp,
    UPDATED_BY varchar2(50 char),
    DELETE_TS timestamp,
    DELETED_BY varchar2(50 char),
    --
    VERSIONING char(1) not null,
    LAST_VERSION_ID varchar2(32),
    --
    primary key (ID)
)^
-- end WEBDAV_WEBDAV_DOCUMENT
-- begin WEBDAV_LOCK_DESCRIPTOR
create table WEBDAV_LOCK_DESCRIPTOR (
    ID varchar2(32),
    VERSION number(10) not null,
    CREATE_TS timestamp,
    CREATED_BY varchar2(50 char),
    UPDATE_TS timestamp,
    UPDATED_BY varchar2(50 char),
    DELETE_TS timestamp,
    DELETED_BY varchar2(50 char),
    --
    TIMEOUT number(19) not null,
    WEBDAV_DOCUMENT_ID varchar2(32) not null,
    --
    primary key (ID)
)^
-- end WEBDAV_LOCK_DESCRIPTOR
-- begin WEBDAV_WEBDAV_LINK
create table WEBDAV_WEBDAV_LINK (
    ID varchar2(32),
    VERSION number(10) not null,
    CREATE_TS timestamp,
    CREATED_BY varchar2(50 char),
    UPDATE_TS timestamp,
    UPDATED_BY varchar2(50 char),
    DELETE_TS timestamp,
    DELETED_BY varchar2(50 char),
    --
    ENTITY_TYPE varchar2(100 char) not null,
    ENTITY_ID varchar2(32) not null,
    CONTEXT varchar2(512 char) not null,
    --
    primary key (ID)
)^
-- end WEBDAV_WEBDAV_LINK
-- begin WEBDAV_WEBDAV_CREDENTIALS
create table WEBDAV_WEBDAV_CREDENTIALS (
    ID varchar2(32),
    VERSION number(10) not null,
    CREATE_TS timestamp,
    CREATED_BY varchar2(50 char),
    UPDATE_TS timestamp,
    UPDATED_BY varchar2(50 char),
    DELETE_TS timestamp,
    DELETED_BY varchar2(50 char),
    --
    WEBDAV_PASSWORD varchar2(255 char) not null,
    USER_ID varchar2(32) not null,
    --
    primary key (ID)
)^
-- end WEBDAV_WEBDAV_CREDENTIALS
-- begin WEBDAV_WEBDAV_TEST_ENTITY
create table WEBDAV_WEBDAV_TEST_ENTITY (
    ID varchar2(32),
    VERSION number(10) not null,
    CREATE_TS timestamp,
    CREATED_BY varchar2(50 char),
    UPDATE_TS timestamp,
    UPDATED_BY varchar2(50 char),
    DELETE_TS timestamp,
    DELETED_BY varchar2(50 char),
    --
    NAME varchar2(255 char) not null,
    FILE_DESCRIPTOR_ID varchar2(32) not null,
    --
    primary key (ID)
)^
-- end WEBDAV_WEBDAV_TEST_ENTITY
