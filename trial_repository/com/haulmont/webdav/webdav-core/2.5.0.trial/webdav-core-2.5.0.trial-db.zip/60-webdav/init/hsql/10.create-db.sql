-- begin WEBDAV_LOCK_DESCRIPTOR
create table WEBDAV_LOCK_DESCRIPTOR (
    ID varchar(36) not null,
    VERSION integer not null,
    CREATE_TS timestamp,
    CREATED_BY varchar(50),
    UPDATE_TS timestamp,
    UPDATED_BY varchar(50),
    DELETE_TS timestamp,
    DELETED_BY varchar(50),
    --
    TIMEOUT bigint not null,
    WEBDAV_DOCUMENT_ID varchar(36) not null,
    --
    primary key (ID)
)^
-- end WEBDAV_LOCK_DESCRIPTOR

-- begin WEBDAV_WEBDAV_DOCUMENT
create table WEBDAV_WEBDAV_DOCUMENT (
    ID varchar(36) not null,
    VERSION integer not null,
    CREATE_TS timestamp,
    CREATED_BY varchar(50),
    UPDATE_TS timestamp,
    UPDATED_BY varchar(50),
    DELETE_TS timestamp,
    DELETED_BY varchar(50),
    --
    VERSIONING boolean not null,
    LAST_VERSION_ID varchar(36),
    --
    primary key (ID)
)^
-- end WEBDAV_WEBDAV_DOCUMENT
-- begin WEBDAV_WEBDAV_DOCUMENT_VERSION
create table WEBDAV_WEBDAV_DOCUMENT_VERSION (
    ID varchar(36) not null,
    VERSION integer not null,
    CREATE_TS timestamp,
    CREATED_BY varchar(50),
    UPDATE_TS timestamp,
    UPDATED_BY varchar(50),
    DELETE_TS timestamp,
    DELETED_BY varchar(50),
    --
    FILE_DESCRIPTOR_ID varchar(36),
    WEBDAV_DOCUMENT_ID varchar(36),
    CONTENT_TYPE varchar(255) not null,
    SHA1SUM varchar(255) not null,
    NATURAL_VERSION_ID bigint,
    --
    primary key (ID)
)^
-- end WEBDAV_WEBDAV_DOCUMENT_VERSION
-- begin WEBDAV_WEBDAV_CREDENTIALS
create table WEBDAV_WEBDAV_CREDENTIALS (
    ID varchar(36) not null,
    VERSION integer not null,
    CREATE_TS timestamp,
    CREATED_BY varchar(50),
    UPDATE_TS timestamp,
    UPDATED_BY varchar(50),
    DELETE_TS timestamp,
    DELETED_BY varchar(50),
    --
    WEBDAV_PASSWORD varchar(255) not null,
    USER_ID varchar(36) not null,
    --
    primary key (ID)
)^
-- end WEBDAV_WEBDAV_CREDENTIALS
-- begin WEBDAV_WEBDAV_TEST_ENTITY
create table WEBDAV_WEBDAV_TEST_ENTITY (
    ID varchar(36) not null,
    VERSION integer not null,
    CREATE_TS timestamp,
    CREATED_BY varchar(50),
    UPDATE_TS timestamp,
    UPDATED_BY varchar(50),
    DELETE_TS timestamp,
    DELETED_BY varchar(50),
    --
    NAME varchar(255) not null,
    FILE_DESCRIPTOR_ID varchar(36) not null,
    --
    primary key (ID)
)^
-- end WEBDAV_WEBDAV_TEST_ENTITY
-- begin WEBDAV_WEBDAV_LINK
create table WEBDAV_WEBDAV_LINK (
    ID varchar(36) not null,
    VERSION integer not null,
    CREATE_TS timestamp,
    CREATED_BY varchar(50),
    UPDATE_TS timestamp,
    UPDATED_BY varchar(50),
    DELETE_TS timestamp,
    DELETED_BY varchar(50),
    --
    ENTITY_TYPE varchar(100) not null,
    ENTITY_ID varchar(36) not null,
    CONTEXT varchar(512) not null,
    --
    primary key (ID)
)^
-- end WEBDAV_WEBDAV_LINK
