insert into sys_lock_config (id, create_ts, name, timeout_sec) values (newid(), current_timestamp, 'webdav$WebdavFileDescriptor', 60000) ;

--<security constraints
insert into SEC_CONSTRAINT 
(ID, VERSION, CREATE_TS, CREATED_BY, UPDATE_TS, UPDATED_BY, DELETE_TS, DELETED_BY, CHECK_TYPE, OPERATION_TYPE, CODE, ENTITY_NAME, JOIN_CLAUSE, WHERE_CLAUSE, GROOVY_SCRIPT, FILTER_XML, IS_ACTIVE, GROUP_ID) 
values ('ab21e489-f9de-a60e-f465-009fffac6ede', 1, '2018-02-13 15:04:25', 'admin', '2018-02-13 15:04:25', null, null, null, 'memory', 'create', null, 'webdav$WebdavDocumentVersion', null, null, 'import com.haulmont.cuba.core.global.AppBeans
import com.haulmont.webdav.tools.WebdavSecurityTools


WebdavSecurityTools wsec = AppBeans.get(WebdavSecurityTools)
return wsec.isUserPermittedToCreateDocumentByWebdavDocumentVersion({E})
', null, true, '0fa2b1a5-1d68-4d69-9fbd-dff348347f93');

insert into SEC_CONSTRAINT 
(ID, VERSION, CREATE_TS, CREATED_BY, UPDATE_TS, UPDATED_BY, DELETE_TS, DELETED_BY, CHECK_TYPE, OPERATION_TYPE, CODE, ENTITY_NAME, JOIN_CLAUSE, WHERE_CLAUSE, GROOVY_SCRIPT, FILTER_XML, IS_ACTIVE, GROUP_ID) 
values ('1822eed8-6dde-8616-d485-8c7d143f32ae', 2, '2018-02-13 14:43:02', 'admin', '2018-02-13 15:04:35', 'admin', null, null, 'memory', 'read', null, 'webdav$WebdavDocumentVersion', null, null, 'import com.haulmont.cuba.core.global.AppBeans
import com.haulmont.webdav.tools.WebdavSecurityTools


WebdavSecurityTools wsec = AppBeans.get(WebdavSecurityTools)
return wsec.isUserPermittedToReadDocumentByWebdavDocumentVersion({E})
', null, true, '0fa2b1a5-1d68-4d69-9fbd-dff348347f93');

insert into SEC_CONSTRAINT 
(ID, VERSION, CREATE_TS, CREATED_BY, UPDATE_TS, UPDATED_BY, DELETE_TS, DELETED_BY, CHECK_TYPE, OPERATION_TYPE, CODE, ENTITY_NAME, JOIN_CLAUSE, WHERE_CLAUSE, GROOVY_SCRIPT, FILTER_XML, IS_ACTIVE, GROUP_ID) 
values ('fa95e0e1-26d1-6af9-71d9-018d0c73cadc', 2, '2018-02-13 15:59:09', 'admin', '2018-02-13 16:00:26', 'admin', null, null, 'memory', 'update', null, 'webdav$WebdavDocumentVersion', null, null, 'import com.haulmont.cuba.core.global.AppBeans
import com.haulmont.webdav.tools.WebdavSecurityTools


WebdavSecurityTools wsec = AppBeans.get(WebdavSecurityTools)
return wsec.isUserPermittedToUpdateDocumentByWebdavDocumentVersion({E})
', null, true, '0fa2b1a5-1d68-4d69-9fbd-dff348347f93');

insert into SEC_CONSTRAINT 
(ID, VERSION, CREATE_TS, CREATED_BY, UPDATE_TS, UPDATED_BY, DELETE_TS, DELETED_BY, CHECK_TYPE, OPERATION_TYPE, CODE, ENTITY_NAME, JOIN_CLAUSE, WHERE_CLAUSE, GROOVY_SCRIPT, FILTER_XML, IS_ACTIVE, GROUP_ID) 
values ('f1e6e1b8-5825-8de4-2aab-15523331e27a', 1, '2018-02-13 16:00:10', 'admin', '2018-02-13 16:00:10', null, null, null, 'memory', 'delete', null, 'webdav$WebdavDocumentVersion', null, null, 'import com.haulmont.cuba.core.global.AppBeans
import com.haulmont.webdav.tools.WebdavSecurityTools


WebdavSecurityTools wsec = AppBeans.get(WebdavSecurityTools)
return wsec.isUserPermittedToDeleteDocumentByWebdavDocumentVersion({E})', null, true, '0fa2b1a5-1d68-4d69-9fbd-dff348347f93');
--security constraints/>

--<scheduled tasks
insert into SYS_SCHEDULED_TASK
(ID, CREATE_TS, CREATED_BY, UPDATE_TS, UPDATED_BY, DELETE_TS, DELETED_BY, DEFINED_BY, BEAN_NAME, METHOD_NAME, CLASS_NAME, SCRIPT_NAME, USER_NAME, IS_SINGLETON, IS_ACTIVE, PERIOD_, TIMEOUT, START_DATE, CRON, SCHEDULING_TYPE, TIME_FRAME, START_DELAY, PERMITTED_SERVERS, LOG_START, LOG_FINISH, LAST_START_TIME, LAST_START_SERVER, METHOD_PARAMS, DESCRIPTION)
values ('3b5711e6-1676-271b-82e9-4d98b69e1150', '2018-04-10 11:18:23', 'admin', '2018-04-10 12:20:49', 'admin', null, null, 'B', 'webdav_WebdavLockExpiredCleaner', 'gcExpiredLocks', null, null, 'admin', null, true, 28800, null, null, null, 'P', null, null, null, null, null, null, null, '<?xml version="1.0" encoding="UTF-8"?>

<params/>
', 'Task for cleaning expired locks');

insert into SYS_SCHEDULED_TASK
(ID, CREATE_TS, CREATED_BY, UPDATE_TS, UPDATED_BY, DELETE_TS, DELETED_BY, DEFINED_BY, BEAN_NAME, METHOD_NAME, CLASS_NAME, SCRIPT_NAME, USER_NAME, IS_SINGLETON, IS_ACTIVE, PERIOD_, TIMEOUT, START_DATE, CRON, SCHEDULING_TYPE, TIME_FRAME, START_DELAY, PERMITTED_SERVERS, LOG_START, LOG_FINISH, LAST_START_TIME, LAST_START_SERVER, METHOD_PARAMS, DESCRIPTION)
values ('cb64da3e-fc59-e7ad-67c9-d4af8b15362d', '2018-04-10 11:20:49', 'admin', '2018-04-10 12:21:18', 'admin', null, null, 'B', 'webdav_WebdavDocumentVersionsCleaner', 'removeUnreferencedVersions', null, null, 'admin', null, true, 2592000, null, null, null, 'P', null, null, null, null, null, null, null, '<?xml version="1.0" encoding="UTF-8"?>

<params/>
', 'Task for removing versions with document=null');
--scheduled tasks/>